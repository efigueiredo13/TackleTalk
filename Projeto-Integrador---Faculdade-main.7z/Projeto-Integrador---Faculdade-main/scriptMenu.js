function Mudarestado(el) {
    var image = document.getElementById("menu-icon");
    var display = document.getElementById(el).style.display;
    if(display == "block"){
        document.getElementById(el).style.display = 'none';
        image.src = "imagens/white-hamburger-menu-icon-24.png";
    }else{
        document.getElementById(el).style.display = 'block';
        image.src = "imagens/x.png"; 
    }
             
}
